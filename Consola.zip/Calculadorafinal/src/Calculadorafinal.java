import java.util.Scanner;

public class Calculadorafinal {

    public static double potencia(double base, double exponente) {
        return Math.pow(base, exponente);
    }

    public static double raizEnesima(double base, double indice) {
        return Math.pow(base, 1.0 / indice);
    }

    public static long factorial(int n) {
        if (n < 0) return -1;
        long fact = 1;
        for (int i = 2; i <= n; i++) {
            fact *= i;
        }
        return fact;
    }

    public static int fibonacci(int n) {
        if (n < 0) return -1;
        int a = 0, b = 1;
        for (int i = 0; i < n; i++) {
            int temp = a;
            a = b;
            b = temp + b;
        }
        return a;
    }

    public static int mcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static int mcm(int a, int b) {
        return a * b / mcd(a, b);
    }

    public static double evaluarEntrada(String entrada) {
        entrada = entrada.toLowerCase().replaceAll("\\s+", "");

        if (entrada.startsWith("sin")) {
            return Math.sin(Math.toRadians(Double.parseDouble(entrada.substring(3))));
        } else if (entrada.startsWith("cos")) {
            return Math.cos(Math.toRadians(Double.parseDouble(entrada.substring(3))));
        } else if (entrada.startsWith("tan")) {
            return Math.tan(Math.toRadians(Double.parseDouble(entrada.substring(3))));
        } else if (entrada.startsWith("fib")) {
            return fibonacci(Integer.parseInt(entrada.substring(3)));
        } else if (entrada.startsWith("fact")) {
            return factorial(Integer.parseInt(entrada.substring(4)));
        } else {
            return Double.parseDouble(entrada);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double resultado = 0;
        boolean continuar = true;

        System.out.println("Calculadora");
        System.out.print("Ingrese el primer numero o funcion (ej: 5, sin30, fact5,fib6): ");
        resultado = evaluarEntrada(sc.next());

        while (continuar) {
            System.out.print("Ingrese una operacion (+, -, *, /, ^, rt, mcd, mcm, = para terminar): ");
            String operacion = sc.next();

            if (operacion.equals("=")) {
                continuar = false;
                break;
            }

            System.out.print("Ingrese el siguiente numero o funcion: ");
            String entrada = sc.next();

            double valor = evaluarEntrada(entrada);

            switch (operacion) {
                case "+":
                    resultado += valor;
                    break;
                case "-":
                    resultado -= valor;
                    break;
                case "*":
                    resultado *= valor;
                    break;
                case "/":
                    resultado /= valor;
                    break;
                case "^":
                    resultado = potencia(resultado, valor);
                    break;
                case "rt":
                    resultado = raizEnesima(resultado, valor);
                    break;
                case "mcd":
                    resultado = mcd((int) resultado, (int) valor);
                    break;
                case "mcm":
                    resultado = mcm((int) resultado, (int) valor);
                    break;
                default:
                    System.out.println("Operación no válida");
                    break;
            }
        }

        System.out.printf("Resultado sin IVA: %.2f%n", resultado);

        System.out.print("Desea aplicar IVA (s/n): ");
        String aplicarIva = sc.next();

        if (aplicarIva.equalsIgnoreCase("s")) {
            System.out.print("Ingrese el porcentaje de IVA (ej: 19 para 19%): ");
            double iva = sc.nextDouble();
            double resultadoConIVA = resultado * (1 + iva / 100);
            System.out.printf("Resultado con IVA (%.2f%%): %.2f%n", iva, resultadoConIVA);
        }

        sc.close();
    }
}